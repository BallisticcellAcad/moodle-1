<?php

$string['pluginname'] = 'QuizOff Game URL';
$string['externalurl'] = 'QuizOff Game URL';
$string['modulename'] = 'QuizOff Game';
$string['modulenameplural'] = 'QuizOff Games';
$string['invalidurl'] = 'Entered URL is invalid';