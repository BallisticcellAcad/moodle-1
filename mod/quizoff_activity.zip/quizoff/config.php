<?php

const JSON_SERVICES_URL = 'http://192.168.10.233/Academico_JSON/public/getTokenByUserId';
