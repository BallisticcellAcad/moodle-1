<?php

$string['pluginname'] = 'Gamelearn Game URL';
$string['externalurl'] = 'Gamelearn Game URL';
$string['modulename'] = 'Gamelearn Game';
$string['modulenameplural'] = 'Gamelearn Games';
$string['invalidurl'] = 'Entered URL is invalid';