<?php

const GAMELEARN_STATIC_PAGE_URL= '/local/staticpage/view.php?page=quizoff&url=';
const GAMELEARN_GAME_URL= 'http://dnes.bg';
const GAMELEARN_CLIENT_ID = 1176 ;
const GAMELEARN_SHARED_KEY = '672d68ab88165a1fb98b9028d3a31fB1';
const GAMELEARN_URL = 'https://int-sso.gamelearn.net/access';
