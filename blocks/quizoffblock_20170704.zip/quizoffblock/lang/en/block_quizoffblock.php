<?php

$string['pluginname'] = 'QuizzOff HTML block';
$string['quizoffblock'] = 'QuizOff HTML block';
$string['title'] = 'QuizOff';
$string['simplehtml:addinstance'] = 'Add a new simple HTML block';
$string['simplehtml:myaddinstance'] = 'Add a new simple HTML block to the My Moodle page';