<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2017070300;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2016051900;        // Requires this Moodle version
$plugin->component = 'block_quizoffblock'; // Full name of the plugin (used for diagnostics)
