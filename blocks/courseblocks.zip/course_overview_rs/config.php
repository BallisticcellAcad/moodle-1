<?php

const RS_CATEGORY_NAME = 'Rosetta Stone';