<?php

const K12_CATEGORY_NAME = 'K12';
const TEACHER_ROLE_NAME = 'teacher';
const STUDENT_ROLE_NAME = 'student';