<?php
require_once($CFG->dirroot.'/blocks/course_overview_rs/config.php');

$categoryName = RS_CATEGORY_NAME;

$string['course_overview_rs:addinstance'] = "Добавен е нов блок Преглед на $categoryName курсовете";
$string['course_overview_rs:myaddinstance'] = "Добавен е нов блок Преглед на $categoryName курсовете на Моето табло";
$string['defaultmaxcoursesdesc'] = "Максимален брой курсове, които да се показват в блок Преглед на $categoryName kursowete, 0 значи показване на всички курсове от $categoryName";
$string['pluginnamecustom'] = "Преглед на $categoryName курсовете";
$string['pluginname'] = "Преглед на $categoryName курсовете";