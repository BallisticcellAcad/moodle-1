<?php

const GL_CATEGORY_NAME = 'GameLearn';